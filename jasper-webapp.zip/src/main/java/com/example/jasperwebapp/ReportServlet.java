package com.example.jasperwebapp;

import net.sf.jasperreports.engine.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/report")
public class ReportServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, java.io.IOException {
        InputStream jrxml = getClass().getResourceAsStream("/reports/sample_report.jrxml");
        JasperReport jasperReport = null;
        try {
            jasperReport = JasperCompileManager.compileReport(jrxml);
        } catch (JRException e) {
            throw new RuntimeException(e);
        }

        Map<String, Object> params = new HashMap<>();
        JasperPrint jasperPrint = null;
        try {
            jasperPrint = JasperFillManager.fillReport(jasperReport, params, new JREmptyDataSource());
        } catch (JRException e) {
            throw new RuntimeException(e);
        }

        resp.setContentType("application/pdf");
        resp.setHeader("Content-Disposition", "inline; filename=report.pdf");
        try {
            JasperExportManager.exportReportToPdfStream(jasperPrint, resp.getOutputStream());
        } catch (JRException e) {
            throw new RuntimeException(e);
        }
    }
}
