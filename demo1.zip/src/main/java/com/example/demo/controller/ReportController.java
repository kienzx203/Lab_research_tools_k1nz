package com.example.demo.controller;

import com.example.demo.service.JasperService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MimeTypeUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ReportController {
    @Autowired
    private JasperService jasperService;

    @GetMapping("/")
    public String uploadForm() {
        return "upload";
    }

    @PostMapping("/upload")
    public void handleUpload(MultipartFile jrxmlFile,
                             HttpServletResponse response,
                             Model model) throws Exception {
        if (jrxmlFile.isEmpty() || !jrxmlFile.getOriginalFilename().endsWith(".jrxml")) {
            model.addAttribute("error", "Please upload a valid .jrxml file");
            response.sendRedirect("/");
            return;
        }

        byte[] pdf = jasperService.generatePdf(jrxmlFile.getInputStream());
        response.setContentType(MediaType.APPLICATION_PDF_VALUE);
        response.setHeader("Content-Disposition", "inline; filename=report.pdf");
        response.getOutputStream().write(pdf);
        response.getOutputStream().flush();
    }
}