package com.example.demo.service;

import net.sf.jasperreports.engine.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;

@Service
public class JasperService {
    public byte[] generatePdf(InputStream jrxmlStream) throws JRException {
        JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlStream);

        JasperPrint jasperPrint = JasperFillManager.fillReport(
                jasperReport,
                new HashMap<>(),
                new JREmptyDataSource()
        );

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        JasperExportManager.exportReportToPdfStream(jasperPrint, out);
        return out.toByteArray();
    }
}
